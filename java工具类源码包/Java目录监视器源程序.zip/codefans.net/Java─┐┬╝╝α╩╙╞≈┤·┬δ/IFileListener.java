package com.lightspeedleader.directorywatcher;

public interface IFileListener extends IResourceListener {

   
}