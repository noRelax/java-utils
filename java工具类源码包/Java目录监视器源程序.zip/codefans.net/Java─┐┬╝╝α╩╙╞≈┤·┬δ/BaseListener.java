package com.lightspeedleader.directorywatcher;


public abstract class BaseListener {


}
